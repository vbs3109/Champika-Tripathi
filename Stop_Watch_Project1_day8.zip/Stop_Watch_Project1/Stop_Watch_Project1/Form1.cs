﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stop_Watch_Project1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int milisec = 0;
        int sec = 0;
        int min = 0;
        int hour = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            milisec++;

            if (milisec == 100)
            {
                sec++;
                milisec = 0;
            }
            if(sec == 60)
            {
                min++;
                sec = 0;
            }
            if(min == 60)
            {
                hour++;
                min = 0;
            }
            Time.Text = hour.ToString() + "  :  " + min.ToString() + "  :  " + sec.ToString() + " : " + milisec.ToString();


}
        private void Time_Click(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void Stop_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void Reset_Click(object sender, EventArgs e)
        {
            milisec = 0;
            sec = 0;
            min = 0;
            hour = 0;
            Time.Text = hour.ToString() + "  :  " + min.ToString() + "  :  " + sec.ToString() + " : " + milisec.ToString();
        }
    }
}
