﻿using System;

namespace Demo_Deligate
{
    class MyProgram
    {
        public delegate void delmethod();

        internal class Program
        {
            public static void display()
            {
                Console.WriteLine("Inside display()");
            }
            public static void show()
            {
                Console.WriteLine("Inside show()");

            }
            public void Print()
            {
                Console.WriteLine("we are in Print");
            }
            static void Main(string[] args)
            {
                Console.WriteLine("Single casting Delegates....!!!");

                delmethod del1 = Program.show;

                delmethod del2 = new delmethod(Program.display);
                Program obj1 = new Program();

                delmethod del3 = obj1.Print;
                del1();
                del2();
                del3();


            }
        }
    }
}