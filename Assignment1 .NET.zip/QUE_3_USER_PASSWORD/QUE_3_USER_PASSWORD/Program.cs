﻿using System;

public class QUE_3_USER_PASSWORD
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string username, password;
            int ctr = 0;
            do
            {
                Console.Write("Input a Username: ");
                username = Console.ReadLine();

                Console.Write("Input a Password: ");
                password = Console.ReadLine();

                if (username != "Champika" || password != "123456") //increasing
                    ctr++;
                else
                    ctr = 1;

            }
            while ((username != "Champika" || password != "123456") && (ctr != 3)); //checking the User name and Password

            if (ctr == 3)
                Console.WriteLine("\nLogin attemp three times. Try later!");
            else
                Console.WriteLine("\nThe Password entered successfully!");

            Console.ReadLine();
        }
    }
}