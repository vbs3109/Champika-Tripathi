﻿using System;

namespace Array_Recursion
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input String>");
            string inputLine = Console.ReadLine();

            Recursion rec = new Recursion();
            rec.InputSet = rec.MakeCharArray(inputLine);
            rec.CalcPermutation(0);

            Console.Write("# of Permutations: " + rec.PermutationCount);
        }
    }
}