﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_2_exception
{
    public class OrderIsLessThanFive : Exception
    {
        public OrderIsLessThanFive(string message)
        {

        }
    }
    class Order
    {
        int ord = 4;

        public void showAge()
        {
            if (ord < 5)
            {
                throw (new OrderIsLessThanFive("Order is less than 5"));
            }
            else
            {
                Console.WriteLine("Order : {0}", ord);
                Console.WriteLine("Order is more than 5");

            }
        }
    }
}
