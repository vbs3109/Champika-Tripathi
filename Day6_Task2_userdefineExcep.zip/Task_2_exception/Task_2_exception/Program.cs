﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_2_exception
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("User Define Exception");
            Order o = new Order();

            try
            {
                o.showAge();
            }
            catch (OrderIsLessThanFive ex)
            {
                Console.WriteLine("Order is less than 5", ex.Message);

            }
        }
    }
}
