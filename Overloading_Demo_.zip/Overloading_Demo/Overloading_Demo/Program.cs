﻿using System;

namespace Overloading_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            Calculator C1 = new Calculator(10, 20);
            C1.Print();
            Calculator C2 = new Calculator(20, 30);
            C2.Print();
            Calculator c3 = new Calculator();
            c3.Print();
            c3 = C1 + C2;
            c3.Print();
        }
    }
}