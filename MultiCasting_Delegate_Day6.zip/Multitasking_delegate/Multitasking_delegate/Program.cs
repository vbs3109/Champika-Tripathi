﻿using System;

namespace Multitasking_delegate
{
    public delegate void delmethod(int x, int y); // declare delegate

   internal  class Program
    {
        public void add(int x , int y)
        {
            Console.WriteLine("You are implementing Add()");
            Console.WriteLine(x + y);
        }
        public void Subtract(int x , int y)
        {
            Console.WriteLine("You are in Subtract Methofd()");
            Console.WriteLine(x - y);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World");
            Program obj1 = new Program();
            delmethod de1 = new delmethod(obj1.add);

            //multicasting

            de1 += new delmethod(obj1.Subtract);
            de1(45, 87);

            de1 -= new delmethod(obj1.add);
            de1(87, 56);
        }
    }
}
