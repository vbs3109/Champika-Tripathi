﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day6_Task_Exception
{

    public class InvalidAgeException : Exception
    {
        public InvalidAgeException(String message) : base(message)
        {

        }
    }
    class Age
    {
        int age = 0;
        public void showAge(int age)
        {
            if (age < 20)
            {
                throw (new InvalidAgeException("Age must not be less than 20"));
            }
            else
            {
                Console.WriteLine("AGe is valid");
            }
        }


    }
}
