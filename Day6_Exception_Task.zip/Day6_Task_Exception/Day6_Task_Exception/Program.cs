﻿using System;

namespace Day6_Task_Exception
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Age Validation!!!!!!!");
            Age age = new Age();
            try
            {
                age.showAge(21);
                //Console.WriteLine(("Age is valid",);
            }
            catch (InvalidAgeException ag)
            {
                Console.WriteLine("Age is Invalid", ag.Message);

                //throw;
            }
        }
    }
}
